package model.logic;

import model.data_structures.HasTable;

public class Hash {
	
	public HasTable<Movie> peliculas;
	
	
	public Hash () {
		peliculas = new HasTable<Movie>();
	}
	
}
